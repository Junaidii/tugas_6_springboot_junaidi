package com.tugas6rosanaulfa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tugas6RosanaUlfaApplicationTests {

    @Test
    void contextLoads() {
    }

}
