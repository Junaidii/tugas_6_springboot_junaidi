package com.tugas6junaidi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tugas6junaidiApplication {

    public static void main(String[] args) {

        SpringApplication.run(Tugas6junaidiApplication.class, args);

    }

}
